import subprocess
subprocess.call("msfconsole -r explanations/msf.rc", shell=True)
